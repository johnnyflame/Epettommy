# Emulator

A minimal smart watch, written in TypeScript.

The folder "emulator" contains the source code for the emulator itself.
For the application prototype code, see "prototype".
Test cases can be found under "Unit Tests" in the emulator index.html. 


To run the smart watch emulator, first compile and build all files (`gulp build`),
then run index.html under Site Root. 

## Other Gulp Tasks

* `gulp typedoc` will generate documentation from the code.

* `gulp tslint` will run tslint over the code.

* `gulp clean` will delete the directories of compiled code and generated documentation.

# Please note

We have included the built files and documentations so that you don't require a
TypeScript environment to make it work. You will also find part of a library we
used in our prototype that makes use of the emulator, and shows several examples
of how to use it. Also see the emulator unit tests. 

If you are desperate, you can contact me on my CS department email. Username is
 `mchilcott`. I apologise in advance that this emulator probably doesn't contain
all the fancy features you expect.